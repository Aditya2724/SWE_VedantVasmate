# consumer_to_s3.py
import json, os
from kafka import KafkaConsumer
import boto3
from datetime import datetime

KAFKA_BROKER = 'localhost:9092'
TOPIC = 'satellite.raw'

S3_ENDPOINT = os.environ.get('S3_ENDPOINT', 'http://localhost:9000')
S3_ACCESS_KEY = os.environ.get('S3_ACCESS_KEY', 'minioadmin')
S3_SECRET_KEY = os.environ.get('S3_SECRET_KEY', 'minioadmin')
BUCKET = 'satellite-raw'

s3 = boto3.resource('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_ACCESS_KEY, aws_secret_access_key=S3_SECRET_KEY)
try:
    s3.create_bucket(Bucket=BUCKET)
except Exception:
    pass

consumer = KafkaConsumer(
    TOPIC,
    bootstrap_servers=[KAFKA_BROKER],
    auto_offset_reset='earliest',
    enable_auto_commit=False,
    value_deserializer=lambda m: json.loads(m.decode('utf-8')),
)

for msg in consumer:
    value = msg.value
    key = value.get('id')
    object_key = f"{value['satellite']}/{datetime.utcnow().date()}/{key}.json"
    s3.Object(BUCKET, object_key).put(Body=json.dumps(value).encode('utf-8'))
    print('stored', object_key)
    consumer.commit()
