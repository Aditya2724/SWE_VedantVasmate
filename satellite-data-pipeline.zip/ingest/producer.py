# producer.py
import json, time, uuid, random
from kafka import KafkaProducer
from datetime import datetime

KAFKA_BROKER = 'localhost:9092'
TOPIC = 'satellite.raw'

producer = KafkaProducer(
    bootstrap_servers=[KAFKA_BROKER],
    value_serializer=lambda v: json.dumps(v).encode('utf-8'),
    linger_ms=10,
)

def fake_image_payload():
    return {
        'id': str(uuid.uuid4()),
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'satellite': random.choice(['SAT-A','SAT-B','SAT-C']),
        'orbit_pass': random.randint(0, 100000),
        'tile_coords': {'x': random.randint(0,10000), 'y': random.randint(0,10000)},
        'size_bytes': random.randint(1000, 10_000_000),
        'data_preview': '...'
    }

if __name__ == '__main__':
    try:
        while True:
            msg = fake_image_payload()
            producer.send(TOPIC, msg)
            producer.flush()
            print('produced', msg['id'])
            time.sleep(0.2)
    except KeyboardInterrupt:
        producer.close()
