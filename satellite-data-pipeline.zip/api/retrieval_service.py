# retrieval_service.py
from fastapi import FastAPI, Depends, HTTPException, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
import boto3, os
from typing import List

app = FastAPI(title='Satellite Retrieval API')

JWT_SECRET = os.environ.get('JWT_SECRET','supersecret')
JWT_ALGO = 'HS256'
S3_ENDPOINT = os.environ.get('S3_ENDPOINT','http://localhost:9000')
S3_ACCESS_KEY = os.environ.get('S3_ACCESS_KEY','minioadmin')
S3_SECRET_KEY = os.environ.get('S3_SECRET_KEY','minioadmin')
BUCKET = 'satellite-processed'

s3 = boto3.client('s3', endpoint_url=S3_ENDPOINT, aws_access_key_id=S3_ACCESS_KEY, aws_secret_access_key=S3_SECRET_KEY)
security = HTTPBearer()

def get_current_roles(credentials: HTTPAuthorizationCredentials = Security(security)) -> List[str]:
    token = credentials.credentials
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
        return payload.get('roles', [])
    except JWTError:
        raise HTTPException(status_code=401, detail='Invalid token')

def require_role(required: str):
    def checker(roles: List[str] = Depends(get_current_roles)):
        if required not in roles:
            raise HTTPException(status_code=403, detail='Insufficient permissions')
        return True
    return checker

@app.get('/list/{satellite}')
def list_objects(satellite: str, allowed: bool = Depends(require_role('scientist'))):
    resp = s3.list_objects_v2(Bucket=BUCKET, Prefix=f'{satellite}/')
    keys = [o['Key'] for o in resp.get('Contents', [])] if 'Contents' in resp else []
    return {'keys': keys}

@app.get('/download')
def download(key: str, allowed: bool = Depends(require_role('scientist'))):
    try:
        url = s3.generate_presigned_url('get_object', Params={'Bucket': BUCKET, 'Key': key}, ExpiresIn=3600)
        return {'url': url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get('/health')
def health():
    return {'status':'ok'}

@app.post('/token')
def make_token(payload: dict):
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)
    return {'token': token}
