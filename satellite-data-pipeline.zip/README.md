# Satellite Data Pipeline

A reference implementation of a satellite data processing pipeline with Kafka, MinIO, Spark, and FastAPI.

## Components
- **Producer**: Simulates satellite data ingestion into Kafka.
- **Consumer**: Reads from Kafka and stores into S3 (MinIO).
- **Processing**: Spark job transforms raw JSON into partitioned Parquet.
- **API**: FastAPI service with JWT RBAC to list and download processed data.

## Run Locally
```bash
docker-compose up -d
python ingest/consumer_to_s3.py
python ingest/producer.py
spark-submit processing/spark_process.py
uvicorn api.retrieval_service:app --reload --port 8000
```
