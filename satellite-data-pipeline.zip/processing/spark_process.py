# spark_process.py
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_timestamp

S3_ENDPOINT = 'http://localhost:9000'
ACCESS_KEY = 'minioadmin'
SECRET_KEY = 'minioadmin'
BUCKET = 'satellite-raw'

spark = SparkSession.builder.appName('satellite-processing').getOrCreate()
hadoop_conf = spark._jsc.hadoopConfiguration()
hadoop_conf.set('fs.s3a.endpoint', S3_ENDPOINT)
hadoop_conf.set('fs.s3a.access.key', ACCESS_KEY)
hadoop_conf.set('fs.s3a.secret.key', SECRET_KEY)
hadoop_conf.set('fs.s3a.path.style.access', 'true')
hadoop_conf.set('fs.s3a.connection.ssl.enabled', 'false')

input_path = f's3a://{BUCKET}/*/*/*.json'
raw = spark.read.json(input_path)

df = raw.withColumn('event_time', to_timestamp(col('timestamp')))
output_path = 's3a://satellite-processed/parquet'
df.write.mode('overwrite').partitionBy('satellite').parquet(output_path)

spark.stop()
